package dk.itu.KF13.TheSim.Game.World;

import java.util.List;

public interface World {
	List<Location> getLocations();
}