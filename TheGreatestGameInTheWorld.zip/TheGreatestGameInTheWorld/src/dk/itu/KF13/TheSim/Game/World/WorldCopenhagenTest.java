package dk.itu.KF13.TheSim.Game.World;

import static org.junit.Assert.*;

import org.junit.Test;

public class WorldCopenhagenTest {

	@Test
	public final void testGetLocations() {
		WorldCopenhagen instance = new WorldCopenhagen();
		
		assertNotNull(instance);
	}

}
